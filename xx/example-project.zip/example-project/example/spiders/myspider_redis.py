from scrapy_redis.spiders import RedisSpider
import scrapy
import json


class MySpider(RedisSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'myspider_redis'
    redis_key = 'myspider:start_urls'
    allowed_domains = ['wanfangdata.com.cn']

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(MySpider, self).__init__(*args, **kwargs)

    def parse(self, response):
        focus_list = response.xpath('//*[@id="D1fBtb"]//div/a/@href').extract()
        focus_url = focus_list[1:7]
        focus_url.append(focus_list[8])
        print(focus_url)
        for url in focus_url:
            if url == '/perio/toIndex.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_qikan,
                                     dont_filter=True)
            elif url == '/conf/load.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_huiyi,
                                     dont_filter=True)

            elif url == '/degree/toIndex.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_xuewei,
                                     dont_filter=True)
            elif url == '/tech/techindex.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_kjbg,
                                     dont_filter=True)
            elif url == '/techResult/tr-nav.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_kjcg,
                                     dont_filter=True)
            elif url == '/navigations/patent.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_zhuanli,
                                     dont_filter=True)
            elif url == '/legislations/toIndex.do':
                yield scrapy.Request(url='http://www.wanfangdata.com.cn' + url, callback=self.get_fagui,
                                     dont_filter=True)

    def get_qikan(self, response):
        for i in range(1,252):
            data = {
                'page': str(i),
                'pageSize': '20',
                'selectOrder': 'affectoi',
            }

            yield scrapy.FormRequest(url='http://www.wanfangdata.com.cn/perio/page.do', formdata=data,
                                     callback=self.get_qikan_year,dont_filter=True)

    def get_qikan_year(self, response):
        dic = json.loads(response.text)

        qikan_list = dic['pageRow']
        for qikan in qikan_list:
            perio_id = qikan['perio_id']
            data = {
                'perio_id': str(perio_id)
            }

            yield scrapy.FormRequest(url='http://www.wanfangdata.com.cn/perio/yearTree.do', formdata=data,
                                     callback=self.get_qikanlist,meta={'perio_id':perio_id}, dont_filter=True)



    def get_qikanlist(self,response):
        year_list = json.loads(response.text)
        for name in year_list:
            for issue in name['issue']:
                data = {
                    'page': '1',
                    'pageSize': '10000',
                    'issue_num': str(issue),
                    'publish_year': name['name'],
                    'perio_id': response.meta['perio_id'],
                }
                yield scrapy.FormRequest(url='http://www.wanfangdata.com.cn/perio/articleList.do', formdata=data,
                                         callback=self.get_qikan_list, dont_filter=True)

    def get_qikan_list(self,response):

        html = json.loads(response.text)
        if html['pageRow'] == None:
            print('没有数据')
            return None
        for id in html['pageRow']:
            yield scrapy.Request(url='http://www.wanfangdata.com.cn/details/detail.do?_type=perio&id={}'.format(id['article_id']), callback=self.get_qikan_info,
                                 dont_filter=True)

    def get_qikan_info(self,response):

        l = response.xpath('//ul[@class="info"]//li/div[1]/text()').extract()
        l2 = response.xpath('//ul[@class="info"]//li/div[2]').extract()
        l3 = []
        for i, j in enumerate(l):
            print(i, j)

        for i, k in zip(l, l2):
            if i == '作者：':
                author_count = len(k.xpath('./a').extract())
            txt = k.xpath('.//a/text()').extract()
            if txt == []:
                txt = k.xpath('./text()').extract_first().replace('\n', '').replace('\t', '').replace('\r', '').replace(' ', '')
            l3.append(txt)

        dic = {}

        for a, b in zip(l, l3):
            if type(b) == list:
                if a == '作者：' or a == 'Author：':
                    b = b[:author_count]
                dic[a] = ','.join(b)
            else:
                dic[a] = b

        print(dic)
        print(author_count)


    def get_xuewei(self, response):
        print(response.url, response.status)

    def get_huiyi(self, response):
        print(response.url, response.status)

    def get_zhuanli(self, response):
        print(response.url, response.status)

    def get_kjbg(self, response):
        print(response.url, response.status)

    def get_kjcg(self, response):
        print(response.url, response.status)

    def get_fagui(self, response):
        print(response.url, response.status)
